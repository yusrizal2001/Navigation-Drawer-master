package com.example.jasaonline.helpers

class Config {
    companion object{
        const val SPLASH_TIME_OUT:Long = 3000
        const val BASE_URL = "http://192.168.43.9:3000/"
        const val EXTRA_FRAGMENT_ID = "FRAGMENT_ID"
    }
}