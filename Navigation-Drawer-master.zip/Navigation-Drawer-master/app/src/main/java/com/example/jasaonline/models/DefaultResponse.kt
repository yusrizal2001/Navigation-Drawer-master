package com.example.jasaonline.models

data class DefaultResponse (
    val message: String,
            val error: Boolean
)